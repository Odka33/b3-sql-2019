INSERT INTO EMPLOYES VALUES ( 8,2,'Callahan','Laura','Assistante commerciale','Mlle','09/01/58','05/03/94', 2000.00, .00 );
INSERT INTO EMPLOYES VALUES ( 5,2,'Buchanan','Steven','Chef des ventes','M.','04/03/55','17/10/93', 8000.00, .00 );
INSERT INTO EMPLOYES VALUES ( 4,2,'Peacock','Margaret','Repr�sentant(e)','Mme','19/09/58','03/05/93', 2856.00, 250.00 );
INSERT INTO EMPLOYES VALUES ( 3,2,'Leverling','Janet','Repr�sentant(e)','Mlle','30/08/63','01/04/92', 3500.00, 1000.00 );
INSERT INTO EMPLOYES VALUES ( 1,2,'Davolio','Nancy','Repr�sentant(e)','Mlle','08/12/68','01/05/92', 3135.00, 1500.00 );
INSERT INTO EMPLOYES VALUES ( 9,5,'Dodsworth','Anne','Repr�sentant(e)','Mlle','02/07/69','15/11/94', 2180.00, .00 ); 
INSERT INTO EMPLOYES VALUES ( 7,5,'King','Robert','Repr�sentant(e)','M.','29/05/60','02/01/94', 2356.00, 800.00 );
INSERT INTO EMPLOYES VALUES ( 6,5,'Suyama','Michael','Repr�sentant(e)','M.','02/07/63','17/10/93', 2534.00, 600.00 ); 
INSERT INTO EMPLOYES VALUES ( 2,2,'Fuller','Andrew','Vice-Pr�sident','Dr.','19/02/52','14/08/92', 10000.00, .00 ); 
