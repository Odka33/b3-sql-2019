INSERT INTO CATEGORIES VALUES ( 1,'Boissons','Boissons, caf�s, th�s, bi�res' );   
INSERT INTO CATEGORIES VALUES ( 2,'Condiments','Sauces, assaisonnements et �pices' );   
INSERT INTO CATEGORIES VALUES ( 3,'Desserts','Desserts et friandises' );   
INSERT INTO CATEGORIES VALUES ( 4,'Produits laitiers','Fromages' );   
INSERT INTO CATEGORIES VALUES ( 5,'P�tes et c�r�ales','Pains, biscuits, p�tes et c�r�ales' );   
INSERT INTO CATEGORIES VALUES ( 6,'Viandes','Viandes pr�par�es' );   
INSERT INTO CATEGORIES VALUES ( 7,'Produits secs','Fruits secs, raisins, autres' );   
INSERT INTO CATEGORIES VALUES ( 8,'Poissons et fruits de mer','Poissons, fruits de mer, escargots' );
